<?php

    // Hi! Start coding below!

/*
if ( !current_user_can( 'administrator' ) ) {
	wp_die('Wait a sec..');
	exit;
}*/
