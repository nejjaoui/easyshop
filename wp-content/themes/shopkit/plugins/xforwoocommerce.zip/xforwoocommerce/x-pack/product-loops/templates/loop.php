<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action( 'product_loops_before' ); ?>

<?php do_action( 'product_loops_content' ); ?>

<?php do_action( 'product_loops_after' ); ?>