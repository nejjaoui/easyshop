<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action( 'product_loops_alt_before' ); ?>

<?php do_action( 'product_loops_alt_content' ); ?>

<?php do_action( 'product_loops_alt_after' ); ?>